 <?php 

    require_once __DIR__ . "../vendor/autoload.php"; 
 
    use voku\helper\HtmlDomParser; 
     
    $curl = curl_init(); 
    curl_setopt($curl, CURLOPT_URL, "https://www.wempe.com/en-int/watches/erwin-sattler/?n=100"); 
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true); 
    $html = curl_exec($curl); 
    curl_close($curl); 
     
    // initialize HtmlDomParser 
    $htmlDomParser = HtmlDomParser::str_get_html($html);

    $paginationElements = $htmlDomParser->find(".listing a");
    $paginationLinks = []; 
    foreach ($paginationElements as $paginationElement) { 
    	// populate the paginationLinks set with the URL 
    	// extracted from the href attribute of the HTML pagination element 
    	$paginationLink = $paginationElement->getAttribute("href"); 
    	// avoid duplicates in the list of URLs 
    	if (!in_array($paginationLink, $paginationLinks)) { 
    		$paginationLinks[] = $paginationLink; 
    	} 
    }

    $SingleProductData = [];
    $d_header = [];
    $d_content = [];
    $counter    =   [];
    foreach($paginationLinks as $key => $values) {
        $curl = curl_init(); 
        curl_setopt($curl, CURLOPT_URL, $values); 
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true); 
        $html = curl_exec($curl); 
        curl_close($curl); 
        $htmlDomParser = HtmlDomParser::str_get_html($html);

        $imageslist = $htmlDomParser->find(".slide__item link[itemprop='image']");

        $product_data = $htmlDomParser->find(".content__details");
        $product_detail = $htmlDomParser->find(".product-detail-box");

        // $title  = $product_data->find('h1 ._d-block',0)->innertext;
        $title  = $product_data->findOne("h1 ._d-block")->text; 
        $sku    = $product_data->findOne("meta[itemprop='sku']")->content;

        if (!$title && !$sku) {
            continue;
        }

        $product_short_description = $product_data->findOne('.details__description._d-block')->text;
        $product_description = $product_detail->findOne('.product-detail-box__description')->text;

        $price = $product_data->findOne('.details__price-wrapper .details__price')->text;

        $product_price = '';
        if ($price) {
            preg_match('/\d+\.?\d*/', $price, $matches);
            $product_price = $matches[0];
        }

        $productDetail = (array)$product_detail->find('.print__col-12 .we-collapse__container');

        $productDetails = [];

        $case = '';
        $movement = '';
        $functions = '';
        $dial = '';
        $strap = '';
        $manufacturer_specifications = '';
        $special_features = '';
        $attrName = array();

        foreach ($productDetail as $pd_key => $productData) {
            $pd_data['header'] = $productData->findOne('.we-collapse__header')->text;
            $pd_data['content'] = $productData->findOne('.we-collapse__content .we-definition-list')->outertext;            

            $dom = new DOMDocument();
            $dom->loadHTML($pd_data['content']);
            $domx = new DOMXPath($dom);
            $entries = $domx->query("//dl");
            // foreach ($entries as $key => $entry) {
            //     $attrName[] = $entry->nodeValue;
            // }

            $rows = array();
            foreach( $entries as $dl_key => $dl ) {
                $cells = array();
                foreach( $dl->getElementsByTagName( 'dt' ) as $dt_key => $dt ) {
                    $dd = $dl->getElementsByTagName( 'dd' )[$dt_key];

                    $cells[] = array(
                        'property' => $dt->nodeValue,
                        'value' => $dd->nodeValue
                    );
                }
                $attrName[] = $cells;
            }

            $productDetails[$pd_key] = $pd_data;
            if ($pd_data['header'] == 'Case') {
                $case = $pd_data['content'];
            }
            if ($pd_data['header'] == 'Movement') {
                $movement = $pd_data['content'];
            }
            if ($pd_data['header'] == 'Functions') {
                $functions = $pd_data['content'];
            }
            if ($pd_data['header'] == 'Dial') {
                $dial = $pd_data['content'];
            }
            if ($pd_data['header'] == 'Strap') {
                $strap = $pd_data['content'];
            }
            if ($pd_data['header'] == 'Manufacturer specifications') {
                $manufacturer_specifications = $pd_data['content'];
            }
            if ($pd_data['header'] == 'Special features') {
                $special_features = $pd_data['content'];
            }
        }

        $single_array = array_merge(...$attrName);

        $attrNames = array_map("unserialize", array_unique(array_map("serialize", $single_array)));

        // $attrNames = array_unique($pageWithNoChildren);

        $SingleProductData[$key]['type'] = 'simple';
        $SingleProductData[$key]['sku'] = (isset($sku) ? $sku : '');
        $SingleProductData[$key]['title'] = (isset($title) ? $title : '');
        $SingleProductData[$key]['published'] = true;
        $SingleProductData[$key]['is_featured'] = true;
        $SingleProductData[$key]['visibility_catalog'] = 'visible';
        $SingleProductData[$key]['short_description'] = (isset($product_short_description) ? $product_short_description : '');
        $SingleProductData[$key]['description'] = (isset($product_description) ? $product_description : '');
        $SingleProductData[$key]['tax_status'] = 'taxable';
        $SingleProductData[$key]['product_price'] = (isset($product_price) ? $product_price : 0);
        $SingleProductData[$key]['category'] = 'Watches > Erwin Sattler';
        // $SingleProductData[$key]['product_details'] = $productDetails;

        $allproductimg = [];
        foreach ($imageslist as $imageslistelement) { 
            // populate the paginationLinks set with the URL 
            // extracted from the href attribute of the HTML pagination element 
            $imageslink = $imageslistelement->getAttribute("href"); 

            $imgsrc = explode('?',$imageslink);
            $allproductimg[]= $imgsrc[0];
        }

        $SingleProductData[$key]['product_image'] = implode(', ', $allproductimg);
        $SingleProductData[$key]['Brand'] = 'Erwin Sattler';
        $SingleProductData[$key]['product_details'] = $case;
        $SingleProductData[$key]['movement'] = $movement;
        $SingleProductData[$key]['functions'] = $functions;
        $SingleProductData[$key]['dial'] = $dial;
        $SingleProductData[$key]['strap'] = $strap;
        $SingleProductData[$key]['manufacturer_specifications'] = $manufacturer_specifications;
        $SingleProductData[$key]['special_features'] = $special_features;

        $i = 1;
        foreach ($attrNames as $attr_key => $attrName) {
            if ($attrName['property']) {
                $SingleProductData[$key]['Attribute '. $i .' name'] = $attrName['property'];
                $SingleProductData[$key]['Attribute '. $i .' value(s)'] = $attrName['value'];
                $SingleProductData[$key]['Attribute '. $i .' visible'] = 1;
                $SingleProductData[$key]['Attribute '. $i .' global'] = 1;
            }
            $i++;
        }

        $counter[$key] = count($attrNames);

    }

    $count = max($counter);

    $csv = create_csv($SingleProductData, $count);

    function create_csv($SingleProductData, $count){
        
        ob_start();

        // Set PHP headers for CSV output.
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename='.time().'_csv_export.csv');

        // Create the headers.
        $header_args = array( 'Type', 'SKU', 'Name', 'Published', 'Is featured?', 'Visibility in catalog', 'Short description', 'Description', 'Tax status', 'Regular price', 'Categories', 'Images', 'Brand', 'Meta: product_details', 'Meta: movement', 'Meta: functions', 'Meta: dial', 'Meta: strap', 'Meta: manufacturer_specifications' , 'Meta: special_features' );

        // $count = count($attrNames);
        $attrs = [];
        $j = 0;
        for($i = 1; $i <= $count; $i++){
            $attrs[$j]['name'] = 'Attribute '. $i .' name';
            $attrs[$j]['value'] = 'Attribute '. $i .' value(s)';
            $attrs[$j]['visible'] = 'Attribute '. $i .' visible';
            $attrs[$j]['global'] = 'Attribute '. $i .' global';
            
            $j++;
        }

        foreach($attrs as $key => $values){
            foreach($values as $k => $value){
                array_push($header_args, $value);
            }
        }

        // $header_args = array( 'ID', 'Name', 'Email' );

        // Prepare the content to write it to CSV file.
        // $data = array(
        //     array('1', 'Test 1', 'test1@test.com'),
        //     array('2', 'Test 2', 'test2@test.com'),
        //     array('3', 'Test 3', 'test3@test.com'),
        // );

        // Clean up output buffer before writing anything to CSV file.
        ob_end_clean();

        // Create a file pointer with PHP.
        $output = fopen( 'php://output', 'w' );

        // Write headers to CSV file.
        fputcsv( $output, $header_args );

        // Loop through the prepared data to output it to CSV file.
        foreach( $SingleProductData as $key => $data_item ){
            fputcsv( $output, $data_item );
        }

        // Close the file pointer with PHP with the updated output.
        fclose( $output );
        exit;
    }

    function dd($data){
        echo "<pre>";
        print_r($data);
        echo "</pre>";
    }

?>